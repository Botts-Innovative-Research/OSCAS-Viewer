/*! For license information please see package.js.LICENSE.txt */
module.exports={type:"commonjs"};